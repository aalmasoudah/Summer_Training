# AI Course Tutor — Docker Setup

## Included files

- `app.py` — Streamlit application
- `.streamlit/config.toml` — native Streamlit theme and server settings
- `requirements.txt` — Python libraries
- `Dockerfile` — container image definition
- `docker-compose.yml` — recommended way to run the app
- `.env.example` — safe environment-variable template
- `.dockerignore` — prevents secrets and local files entering the image

## Requirements

1. Docker Desktop
2. One AI provider:
   - Gemini API key, or
   - LM Studio running on the host computer with a loaded chat model

## Start with Gemini

From this folder in Command Prompt:

```bat
copy .env.example .env
notepad .env
```

Put the real key only in `.env`:

```text
GEMINI_API_KEY=your_real_key_here
```

Then run:

```bat
docker compose up --build
```

Open:

```text
http://localhost:8501
```

## Start with LM Studio

1. Open LM Studio.
2. Load the chat/instruct model.
3. Start the local server on port `1234`.
4. Make sure the server accepts connections from Docker.
5. Leave this in `.env`:

```text
LM_STUDIO_BASE_URL=http://host.docker.internal:1234/v1
```

Run:

```bat
docker compose up --build
```

Open `http://localhost:8501` and choose **LM Studio Local Server**.

If the container cannot connect, configure LM Studio to listen on a host-accessible interface rather than only an isolated loopback interface.

## Stop

```bat
docker compose down
```

## Rebuild after code changes

```bat
docker compose up --build
```

## View logs

```bat
docker compose logs -f
```

## Security

- Real API keys belong only in `.env` or the host environment.
- `.env` is excluded by both `.gitignore` and `.dockerignore`.
- No real API key is stored in `app.py`, `Dockerfile`, or `docker-compose.yml`.
- Do not upload or commit `.env`.
